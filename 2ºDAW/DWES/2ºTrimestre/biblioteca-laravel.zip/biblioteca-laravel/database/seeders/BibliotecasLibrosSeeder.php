<?php

namespace Database\Seeders;

use App\Models\Biblioteca;
use App\Models\Libro;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BibliotecasLibrosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        //Biblioteca 1 con sus libros
        $biblioteca1 = Biblioteca::create([
            'nombre' => 'Biblioteca Municipal de Arahal',
            'direccion' => 'Avenida de María Luisa Num 8',
            'horario' => 'De Lunes a Viernes de 9:00 a 20:00',
        ]);

        $libro1 = Libro::create([
            'titulo' => 'El Quijote',
            'autor' => 'Miguel de Cervantes',
            'numPaginas' => 700,
            'disponible' => true,
            'biblioteca_id' => $biblioteca1->id,
        ]);

        $libro2 = Libro::create([
            'titulo' => 'Harry Potter y la flauta mágica',
            'autor' => 'JK Rowling',
            'numPaginas' => 930,
            'disponible' => false,
            'biblioteca_id' => $biblioteca1->id,
        ]);

        $libro3 = Libro::create([
            'titulo' => 'Los Juegos del Hambre: Con mucha agua',
            'autor' => 'Suzanne Collins',
            'numPaginas' => 460,
            'disponible' => true,
            'biblioteca_id' => $biblioteca1->id,
        ]);



        //Biblioteca 2 con sus libros
        $biblioteca2 = Biblioteca::create([
            'nombre' => 'Biblioteca Pública de Marchena',
            'direccion' => 'Calle Dr. Diego Sánchez Num 18',
            'horario' => 'De Lunes a Viernes de 9:00 a 21:00',
        ]);

        $libro4 = Libro::create([
            'titulo' => 'Lo que el viento se llevó: el libro',
            'autor' => 'Bertín Osborne',
            'numPaginas' => 28,
            'disponible' => true,
            'biblioteca_id' => $biblioteca2->id,
        ]);

        $libro5 = Libro::create([
            'titulo' => 'El retrato de Dorian Gray',
            'autor' => 'Oscar Wilde',
            'numPaginas' => 274,
            'disponible' => false,
            'biblioteca_id' => $biblioteca2->id,
        ]);

    }
}
