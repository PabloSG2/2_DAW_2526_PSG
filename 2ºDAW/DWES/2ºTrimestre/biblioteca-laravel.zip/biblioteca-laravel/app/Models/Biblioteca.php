<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Biblioteca extends Model
{
    protected $fillable = ['nombre', 'direccion', 'horario'];

    // Relación uno a muchos
    public function libros()
    {
        return $this->hasMany(Libro::class);
    }

}
