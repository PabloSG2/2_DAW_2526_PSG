<li class="tweet">
    <div class="contenido">
        <div class="cabecera">

            
            <a href="<?php echo e(route("ver_tweet", ["id" => $tweet->id])); ?>">
                <img class="avatarSmall" src="<?php echo e(asset('images/avatars/' . $tweet->user->userName . '-small.jpg')); ?>" />
                <strong><?php echo e($tweet->user->name); ?></strong>
                <span><?php echo e($tweet->user->userName); ?></span>
            </a>
            <small class="time"><?php echo e($tweet->date); ?></small>
        </div>
        <div class="mensaje"><?php echo e($tweet->text); ?></div>
        <div class="likes"><?php echo e($tweet->likedByUsers()->count()); ?> 👍</div>
    </div>
</li><?php /**PATH C:\Users\algoc\Desktop\tweetravel\resources\views/tweet.blade.php ENDPATH**/ ?>