<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent("titulo"); ?> - Tweetravel</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>

<body>
    <div class="topnav">
        <img id="logo" src="<?php echo e(asset('images/logo.png')); ?>" />
        <a href="<?php echo e(route('index')); ?>">Inicio</a>
    </div>
    <div id="principal">
        <?php echo $__env->yieldContent("principal"); ?>
    </div>
</body>

</html><?php /**PATH C:\Users\algoc\Desktop\tweetravel\resources\views/base.blade.php ENDPATH**/ ?>