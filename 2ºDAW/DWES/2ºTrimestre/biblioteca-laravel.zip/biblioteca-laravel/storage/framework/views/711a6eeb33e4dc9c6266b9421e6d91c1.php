

<?php $__env->startSection('titulo'); ?>
<?php echo e($tweet->user->name); ?> <?php echo e($tweet->text); ?>

<?php echo \Illuminate\View\Factory::parentPlaceholder('titulo'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('principal'); ?>
<div class="singleTweet">
    <div class="cabecera">
        <a href="<?php echo e(route("ver_tweet", ["id" => $tweet->id])); ?>">
            <img class="avatarBig" src="<?php echo e(asset('images/avatars/' . $tweet->user->userName . '-small.jpg')); ?>" />
            <strong><?php echo e($tweet->user->name); ?></strong>
            <span><?php echo e($tweet->user->userName); ?></span>
        </a>
        <small class="time"><?php echo e($tweet->date); ?></small>
    </div>
    <div class="mensaje"><?php echo e($tweet->text); ?></div>
    <div class="likes"><?php echo e($tweet->likedByUsers()->count()); ?> 👍</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\algoc\Desktop\tweetravel\resources\views/verTweet.blade.php ENDPATH**/ ?>