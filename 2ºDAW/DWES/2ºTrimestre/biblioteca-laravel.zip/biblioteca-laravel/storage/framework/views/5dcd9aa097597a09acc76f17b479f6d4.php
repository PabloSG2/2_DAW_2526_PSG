

<?php $__env->startSection('titulo'); ?>
Tweetline
<?php echo \Illuminate\View\Factory::parentPlaceholder('titulo'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('principal'); ?>
<ul class="tweetline">
    <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('tweet', ["tweet" => $tweet], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\algoc\Desktop\tweetravel\resources\views/index.blade.php ENDPATH**/ ?>