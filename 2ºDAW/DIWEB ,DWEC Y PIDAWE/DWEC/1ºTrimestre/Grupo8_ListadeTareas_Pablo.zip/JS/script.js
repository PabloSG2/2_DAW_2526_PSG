/* Lista principal donde se almacenan las tareas */
let tasks = []; /* Array de objetos con texto y estado */

/* Función para añadir una nueva tarea */
function addTask() {
  const input = document.getElementById('taskInput'); /* Captura del campo de texto */
  const taskText = input.value.trim(); /* Elimina espacios en blanco al inicio y final */

  if (taskText === "") { /* Si no se escribe nada */
    alert("Por favor, escribe una tarea."); /* Muestra aviso */
    return; /* Sale de la función */
  }
  const newTask = { text: taskText, completed: false }; /* Crea objeto tarea */

  tasks.push(newTask); /* Añade la tarea al array */
  input.value = ""; /* Limpia el campo de texto */
  updateTaskList(); /* Actualiza la lista visible */
}

/* Función que genera y muestra la lista de tareas */
function updateTaskList() {
  const list = document.getElementById('taskList'); /* Captura la lista del HTML */
  list.innerHTML = ""; /* Limpia la lista anterior */

  tasks.forEach((task, index) => { /* Recorre todas las tareas */
    const li = document.createElement('li'); /* Crea un elemento <li> */
    li.className = task.completed ? "done" : "pending"; /* Aplica clase según estado */

    li.innerHTML = `
      <span>${task.text}</span>
      <div class="actions">
        <button onclick="toggleTask(${index})">✔</button>
        <button onclick="deleteTask(${index})">🗑</button>
      </div>
    `; /* Inserta el texto y los botones dentro del <li> */

    list.appendChild(li); /* Añade la tarea a la lista */
  });
  updateStats(); /* Actualiza el porcentaje de progreso */
}

/* Función para eliminar una tarea */
function deleteTask(index) {
  tasks.splice(index, 1); /* Borra la tarea del array */
  updateTaskList(); /* Vuelve a mostrar la lista */
}

/* Función para marcar una tarea como hecha o pendiente */
function toggleTask(index) {
  tasks[index].completed = !tasks[index].completed; /* Cambia el estado booleano */
  updateTaskList(); /* Refresca la vista */
}

/* Función para calcular y mostrar el porcentaje de tareas completadas */
function updateStats() {
  const total = tasks.length; /* Número total de tareas */
  const completed = tasks.filter(task => task.completed).length; /* Contadas las hechas */
  const percent = total > 0 ? Math.round((completed / total) * 100) : 0; /* Cálculo porcentaje */

  document.getElementById('taskStats').innerText = `${percent}% completado`; /* Muestra texto */
  document.getElementById('progressBar').style.width = `${percent}%`; /* Ajusta la barra verde */
}  