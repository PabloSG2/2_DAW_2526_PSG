// session-model.js
// Gestiona la sesión del usuario con localStorage

const SessionModel = {
  // Guardar usuario activo en localStorage
  guardarUsuario: function(usuario) {
    localStorage.setItem('usuarioActivo', JSON.stringify(usuario)); // Guardamos objeto
  },

  // Obtener usuario activo de localStorage
  obtenerUsuario: function() {
    const usuario = localStorage.getItem('usuarioActivo'); // Leemos storage
    return usuario ? JSON.parse(usuario) : null; // Devolvemos objeto o null
  },

  // Cerrar sesión
  cerrarSesion: function() {
    localStorage.removeItem('usuarioActivo'); // Eliminamos usuario activo
  }
};
