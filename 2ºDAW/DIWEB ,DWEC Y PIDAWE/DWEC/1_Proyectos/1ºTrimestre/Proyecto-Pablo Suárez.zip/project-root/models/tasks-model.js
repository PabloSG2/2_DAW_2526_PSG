// Array donde se guardan las tareas
let tareas = []; // Inicialmente vacío

// Función para agregar tarea
function agregarTarea(titulo) {
  tareas.push({
    id: Date.now(), // ID único
    titulo: titulo, // Título de tarea
    done: false     // Estado inicial
  });
  console.log("Tarea añadida:", titulo); // Depuración
}

// Cambiar estado de tarea
function toggleTarea(id) {
  for (let i = 0; i < tareas.length; i++) { // Buscar tarea
    if (tareas[i].id === id) {
      tareas[i].done = !tareas[i].done; // Alternar done
      return;
    }
  }
}

// Eliminar tarea por ID
function borrarTarea(id) {
  tareas = tareas.filter(function(t) { // Filtrar tareas
    return t.id !== id; // Mantener las demás
  });
}

// Obtener resumen de tareas
function resumenTareas() {
  let total = tareas.length; // Total tareas
  let completadas = tareas.filter(t => t.done).length; // Completadas
  let pendientes = total - completadas; // Pendientes
  return { total, completadas, pendientes }; // Retornar resumen
}
