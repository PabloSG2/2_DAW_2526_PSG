// Array donde se guardarán los usuarios registrados
let usuarios = []; // Lista de usuarios

// Función para agregar un usuario al array
function agregarUsuario(nombre, correo, clave) {
  usuarios.push({ nombre: nombre, correo: correo, clave: clave }); // Añade usuario
  console.log("Usuario añadido:", nombre, correo); // Mensaje de depuración
}

// Función para buscar un usuario por correo y clave
function buscarUsuario(correo, clave) {
  for (let i = 0; i < usuarios.length; i++) { // Recorremos usuarios
    if (usuarios[i].correo === correo && usuarios[i].clave === clave) { // Coincidencia
      return usuarios[i]; // Retornar usuario encontrado
    }
  }
  return null; // No encontrado
}

// Función para obtener todos los usuarios
function obtenerUsuarios() {
  return usuarios; // Retorna array completo
}
