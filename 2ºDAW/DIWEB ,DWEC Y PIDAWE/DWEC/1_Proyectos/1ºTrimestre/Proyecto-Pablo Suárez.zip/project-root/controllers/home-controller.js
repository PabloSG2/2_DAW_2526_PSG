// ===== HOME CONTROLLER =====

// Elementos del DOM
const usuarioActivoTexto = document.getElementById('usuarioActivoTexto');
const logoutBtn = document.getElementById('logout-btn');
const clockElement = document.getElementById('clock');

// ===== RELOJ =====
function actualizarReloj() {
  const now = new Date();
  const horas = now.getHours().toString().padStart(2, '0');
  const minutos = now.getMinutes().toString().padStart(2, '0');
  const segundos = now.getSeconds().toString().padStart(2, '0');
  clockElement.textContent = `${horas}:${minutos}:${segundos}`;
}

// Iniciar reloj si existe elemento
if (clockElement) {
  actualizarReloj(); // Mostrar de inmediato
  setInterval(actualizarReloj, 1000); // Actualizar cada segundo
}

// ===== USUARIO ACTIVO =====
// Mostrar nombre del usuario guardado en sesión
if (usuarioActivoTexto && sessionStorage.getItem('usuarioActivo')) {
  usuarioActivoTexto.textContent = `Bienvenido, ${sessionStorage.getItem('usuarioActivo')}`;
}

// ===== CERRAR SESIÓN =====
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    sessionStorage.removeItem('usuarioActivo'); // Limpiar sesión
    window.location.href = 'register-login.html'; // Volver al login
  });
}
