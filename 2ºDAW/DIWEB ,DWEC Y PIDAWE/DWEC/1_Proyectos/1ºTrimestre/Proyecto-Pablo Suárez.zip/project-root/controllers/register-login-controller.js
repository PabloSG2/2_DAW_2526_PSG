// ===== REGISTER & LOGIN CONTROLLER =====

// Formularios y botones
const formRegistro = document.getElementById('form-registro');
const formLogin = document.getElementById('form-login');
const btnRegistro = document.getElementById('btnRegistro');
const btnLogin = document.getElementById('btnLogin');

// ===== ALTERNAR ENTRE FORMULARIOS =====
if (btnRegistro && btnLogin) {
  btnRegistro.addEventListener('click', () => {
    formRegistro.style.display = 'block'; // Mostrar registro
    formLogin.style.display = 'none';     // Ocultar login
  });

  btnLogin.addEventListener('click', () => {
    formLogin.style.display = 'block';    // Mostrar login
    formRegistro.style.display = 'none';  // Ocultar registro
  });
}

// ===== REGISTRO =====
if (formRegistro) {
  formRegistro.addEventListener('submit', (e) => {
    e.preventDefault();

    const nombre = document.getElementById('reg-nombre').value;
    const correo = document.getElementById('reg-correo').value;
    const clave = document.getElementById('reg-clave').value;

    // Guardar usuario en localStorage
    const usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');
    usuarios.push({ nombre, correo, clave });
    localStorage.setItem('usuarios', JSON.stringify(usuarios));

    alert('Usuario registrado correctamente');

    // Pasar al login automáticamente
    formRegistro.style.display = 'none';
    formLogin.style.display = 'block';
  });
}

// ===== LOGIN =====
if (formLogin) {
  formLogin.addEventListener('submit', (e) => {
    e.preventDefault();

    const correo = document.getElementById('login-correo').value;
    const clave = document.getElementById('login-clave').value;

    const usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');
    const usuarioValido = usuarios.find(u => u.correo === correo && u.clave === clave);

    if (usuarioValido) {
      sessionStorage.setItem('usuarioActivo', usuarioValido.nombre); // Guardar sesión
      window.location.href = 'home.html'; // Redirigir a home
    } else {
      alert('Usuario o contraseña incorrectos');
    }
  });
}
