// Esperar a que el DOM esté cargado
document.addEventListener('DOMContentLoaded', () => {

  // --- Botón modo oscuro/claro ---
  const btnModo = document.getElementById('theme-btn'); // Botón
  const iconoModo = document.getElementById('theme-btn'); // Icono
  const darkImg = '../img/dark.png'; // Luna
  const sunImg = '../img/sun.png';   // Sol

  // Función alternar tema
  function alternarTema() {
    const body = document.body; // Body

    if (body.classList.contains('dark-mode')) {
      body.classList.remove('dark-mode'); // Quitar dark
      body.classList.add('light-mode');   // Poner light
      iconoModo.src = sunImg;             // Icono sol
    } else {
      body.classList.remove('light-mode'); // Quitar light
      body.classList.add('dark-mode');     // Poner dark
      iconoModo.src = darkImg;             // Icono luna
    }
  }

  // Asociar click
  if (btnModo) btnModo.addEventListener('click', alternarTema);

  // Inicializar tema
  document.body.classList.add('light-mode'); // Light por defecto
  if (iconoModo) iconoModo.src = sunImg;     // Icono sol
});
