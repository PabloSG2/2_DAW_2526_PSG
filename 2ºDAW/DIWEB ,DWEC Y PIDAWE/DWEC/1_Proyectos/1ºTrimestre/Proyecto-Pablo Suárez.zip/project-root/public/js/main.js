// ===== CAMBIO DE TEMA CLARO/OSCURO =====

// Referencias al body y al botón del tema
const body = document.querySelector('body');
const themeBtn = document.getElementById('theme-btn');

// Función para alternar tema
function toggleTheme() {
  if (body.classList.contains('light-mode')) {
    body.classList.remove('light-mode'); // Quitar modo claro
    body.classList.add('dark-mode');     // Añadir modo oscuro
    if (themeBtn) themeBtn.src = getThemeIcon('dark'); // Cambiar imagen
    localStorage.setItem('tema', 'dark'); // Guardar tema
  } else {
    body.classList.remove('dark-mode');  // Quitar modo oscuro
    body.classList.add('light-mode');    // Añadir modo claro
    if (themeBtn) themeBtn.src = getThemeIcon('light'); // Cambiar imagen
    localStorage.setItem('tema', 'light'); // Guardar tema
  }
}

// Obtener ruta correcta de icono según página y tema
function getThemeIcon(tema) {
  // Determinar la ruta según la ubicación de la página
  const path = window.location.pathname; 
  let imgFolder = '../img/'; // valor por defecto
  if (path.includes('landing.html')) imgFolder = './img/'; // landing
  // Retorna ruta de la imagen según el tema
  return tema === 'dark' ? imgFolder + 'dark.png' : imgFolder + 'sun.png';
}

// Inicializar tema al cargar la página
function initTheme() {
  const savedTheme = localStorage.getItem('tema') || 'light'; // Recuperar tema guardado
  body.classList.remove('light-mode', 'dark-mode');            // Quitar cualquier clase
  body.classList.add(savedTheme + '-mode');                    // Aplicar clase correspondiente
  if (themeBtn) themeBtn.src = getThemeIcon(savedTheme);      // Ajustar imagen del botón
}

// Evento click para cambiar tema
if (themeBtn) {
  themeBtn.addEventListener('click', toggleTheme);
}

// Ejecutar al cargar
initTheme();
