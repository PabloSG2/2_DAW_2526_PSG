# App MVC - Proyecto 

Este proyecto es una aplicación web educativa que implementa el patrón **MVC (Modelo-Vista-Controlador)**. Permite registro y login de usuarios, cambio de tema (claro/oscuro) y gestión de tareas básicas con reloj incluido.

---

## 📁 Estructura de archivos

### **HTML**
- **landing.html**  
  Página de bienvenida. Muestra un mensaje de introducción y un enlace al registro/login. Permite cambiar entre modo claro y oscuro con un botón.  

- **register-login.html**  
  Página con formularios de registro y login. Incluye botones para alternar entre ambos formularios.  

- **home.html**  
  Página principal del usuario después de iniciar sesión. Muestra usuario activo, reloj en tiempo real y un listado de tareas con opción de añadir nuevas. Permite cerrar sesión y cambiar tema.

---

### **CSS**
- **reset.css**  
  Reinicia los márgenes y padding por defecto y establece box-sizing para todos los elementos.  

- **styles.css**  
  Contiene estilos generales, incluyendo los modos claro y oscuro, header, footer y botones.  

- **forms.css**  
  Estilos específicos para formularios de registro y login: campos, botones y contenedores.

---

### **JavaScript**
- **main.js**  
  - Controla el cambio de tema (claro/oscuro) en todas las páginas.  
  - Actualiza la imagen del botón de tema (`sun.png` / `dark.png`).  
  - Mantiene la preferencia de tema aunque se cambie de página.

- **landing-controller.js**  
  - Controla el contenido dinámico de `landing.html`.  
  - Muestra mensajes de bienvenida y aplica tema actual.

- **register-login-controller.js**  
  - Gestiona los formularios de registro y login.  
  - Alterna la visualización de los formularios.  
  - Valida datos y guarda sesión de usuario.  
  - Redirige al `home.html` tras login o registro exitoso.

- **home-controller.js**  
  - Muestra el usuario activo en la interfaz.  
  - Gestiona el reloj en tiempo real.  
  - Permite añadir tareas y actualizar el resumen de tareas.  
  - Permite cerrar sesión.

---

### **Models**
- **user-model.js**  
  - Simula almacenamiento de usuarios.  
  - Contiene funciones para registrar, buscar y validar usuarios.

- **sesion-model.js**  
  - Gestiona la sesión de usuario activo.  
  - Guarda y obtiene información del usuario conectado.  
  - Permite cerrar sesión.

- **tasks-model.js**  
  - Gestiona las tareas del usuario.  
  - Permite añadir, listar y contar tareas completadas.

---

### **Imágenes**
- **sun.png**  
  Icono para modo claro.  

- **dark.png**  
  Icono para modo oscuro.

---

## ⚡ Características principales
1. Registro y login de usuarios con validación básica.  
2. Cambio de tema entre claro y oscuro en todas las páginas.  
3. Panel de usuario con reloj y tareas.  
4. Gestión de sesión de usuario.  
5. Interfaz limpia y responsive basada en contenedores y botones estilizados.

---

## 📝 Cómo ejecutar
1. Clonar el proyecto.  
2. Abrir `landing.html` en un navegador moderno.  
3. Navegar entre las páginas usando los enlaces o completar registro/login.  
4. Cambiar el tema usando el botón del header.

---

## ✅ Notas
- Todos los datos se almacenan en memoria (simulación), no hay base de datos real.  
- El proyecto está diseñado con fines educativos para demostrar el patrón MVC en frontend.  
- Recomendado usar Chrome, Firefox o Edge para mejor compatibilidad.
